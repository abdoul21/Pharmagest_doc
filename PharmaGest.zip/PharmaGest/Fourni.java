package PharmaGest;

import java.sql.Date;

public class Fourni {
    private int idfourn;
    private String nom;
    private String prenom;
    private String adresse;
    private String email;
    private int tel;

    public Fourni( int idfourn,String nom, String prenom, String adresse, String email, int tel) {
        super();
        this.idfourn=idfourn;
        this.nom=nom;
        this.prenom=prenom;
        this.adresse=adresse;
        this.email=email;
        this.tel=tel;
    }
    public int getIdfourn() {
        return idfourn;
    }

    public void setIdfourn(int idfourn) {
        this.idfourn = idfourn;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }
}
