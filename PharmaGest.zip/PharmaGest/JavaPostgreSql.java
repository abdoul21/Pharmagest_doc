package PharmaGest;

import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.util.Callback;

import java.sql.*;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaPostgreSql {

    public static void writeToDatabase(String nom_med, String dosage_med, String prix_med, String remarque_med, String code_med, String stocks_med,LocalDate test_med ) {

        String url = "jdbc:postgresql://localhost:5432/pharmacie";
        String user = "postgres";
        String password = "0605";

        String nom = nom_med;
        String dosage= dosage_med;
        String prix = prix_med;
        String remarque= remarque_med;
        String code_medicament= code_med;
        String stocks= stocks_med;
        LocalDate date_expiration = test_med;

        // query
        String query = "INSERT INTO medicament(nom, dosage, date_expiration, prix, remarque, code_medicament, stocks) VALUES(?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, nom);
            pst.setString(2, dosage);
            pst.setDate(3, Date.valueOf(date_expiration));
            pst.setInt(4, Integer.parseInt(prix));
            pst.setString(5, remarque);
            pst.setInt(6, Integer.parseInt(code_medicament));
            pst.setInt(7, Integer.parseInt(stocks));


            pst.executeUpdate();
            System.out.println("Sucessfully created.");

        } catch (SQLException ex) {

            Logger lgr = Logger.getLogger(JavaPostgreSql.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
        }

    }
}

