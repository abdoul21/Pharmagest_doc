package PharmaGest;
import javafx.application.Application;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;


public class Stock {


	private TableView<Product> table;

	private ObservableList<Product> products;

	private TextField nameInput, quantityInput;







	public void start(Stage primaryStage) {

		primaryStage.setTitle("Pharmacy Stock Management");


// Créer une liste observable de produits

		products = FXCollections.observableArrayList();


// Créer la table de produits

		table = new TableView<>();

		table.setItems(products);

		table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);


		TableColumn<Product, String> nameColumn = new TableColumn<>("Nom");

		nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());


		TableColumn<Product, Integer> quantityColumn = new TableColumn<>("Quantité");

		quantityColumn.setCellValueFactory(cellData -> cellData.getValue().quantityProperty().asObject());


		table.getColumns().add(nameColumn);

		table.getColumns().add(quantityColumn);


// Créer les champs de saisie et les boutons

		nameInput = new TextField();

		nameInput.setPromptText("Nom du produit");

		nameInput.setMinWidth(150);


		quantityInput = new TextField();

		quantityInput.setPromptText("Quantité");

		quantityInput.setMinWidth(100);


		Button addButton = new Button("Ajouter");

		addButton.setOnAction(e -> addProduct());


		Button deleteButton = new Button("Supprimer");

		deleteButton.setOnAction(e -> deleteProduct());


// Créer le layout

		HBox hbox = new HBox();

		hbox.setSpacing(10);

		hbox.setPadding(new Insets(10, 10, 10, 10));

		hbox.getChildren().addAll(nameInput, quantityInput, addButton, deleteButton);


		VBox vbox = new VBox();

		vbox.getChildren().addAll(table, hbox);


// Afficher la scène

		Scene scene = new Scene(vbox);

		primaryStage.setScene(scene);

		primaryStage.show();

	}


// Ajouter un produit dans le stock

	private void addProduct() {

		String name = nameInput.getText();

		int quantity = Integer.parseInt(quantityInput.getText());

		Product product = new Product(name, quantity);

		products.add(product);

		nameInput.clear();

		quantityInput.clear();

	}


// Supprimer un produit du stock

	private void deleteProduct() {

		int selectedIndex = table.getSelectionModel().getSelectedIndex();

		if (selectedIndex >= 0) {

			table.getItems().remove(selectedIndex);

		}

	}


// Classe de modèle pour un produit

	public static class Product {

		private final String name;

		private final int quantity;


		public Product(String name, int quantity) {

			this.name = name;

			this.quantity = quantity;

		}


		public String getName() {

			return name;

		}


		public int getQuantity() {

			return quantity;

		}


		public StringProperty nameProperty() {

			return new SimpleStringProperty(name);

		}


		public IntegerProperty quantityProperty() {

			return new SimpleIntegerProperty(quantity);

		}

	}

}
