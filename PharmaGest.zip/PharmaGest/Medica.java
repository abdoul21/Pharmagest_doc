package PharmaGest;

import javafx.scene.control.DatePicker;

public class Medica {
    private String nom ;
    private String dosage ;
    private int prix ;
    private String remarque ;
    private int stocks ;
    private int code_medicament ;
    private int id_m ;
    private String date_expiration ;

    public Medica(int id_m,String nom, String dosage, int prix, String remarque, int stocks, int code_medicament, String date_expiration) {
        super();
        this.nom=nom;
        this.id_m = id_m;
        this.dosage=dosage;
        this.prix=prix;
        this.remarque=remarque;
        this.stocks=stocks;
        this.code_medicament=code_medicament;
        this.date_expiration=date_expiration;
    }


    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public int getId_m() {
        return id_m;
    }
    public void setId_m(int id_m) {
        this.id_m = id_m;
    }



    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public String getRemarque() {
        return remarque;
    }

    public void setRemarque(String remarque) {
        this.remarque = remarque;
    }
    public int getStocks() {
        return stocks;
    }

    public void setStocks(int stocks) {
        this.stocks = stocks;
    }

    public int getCode_medicament() {
        return code_medicament;
    }

    public void setCode_medicament(int code_medicament) {
        this.code_medicament = code_medicament;
    }



    public String getDate_expiration() {
        return date_expiration;
    }

    public void setDate_expiration(String date_expiration) {
        this.date_expiration = date_expiration;
    }


}
