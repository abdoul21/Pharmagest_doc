package PharmaGest;

import java.sql.Date;

public class Medica {
    private int code_medicament;
    private String nom;
    private String dosage;
    private int prix;
    private String remarque;
    private int stocks;
    private Date date_expiration;

    public Medica(int code_medicament, String nom, String dosage, int prix, String remarque, int stocks, Date date_expiration){
        this.code_medicament = code_medicament;
        this.nom=nom;
        this.dosage = dosage;
        this.prix=prix;
        this.remarque=remarque;
        this.stocks=stocks;
        this.date_expiration = date_expiration;
    }

    public int getCode_medicament() {
        return code_medicament;
    }
    public String getNom() {
        return nom;
    }

    public String getDosage() {

        return dosage;
    }
    public int getPrix() {

        return prix;
    }

    public String getRemarque() {

        return remarque;
    }

    public int getStocks() {

        return stocks;
    }

    public Date getDate_expiration() {

        return date_expiration;
    }

}
