package PharmaGest;

import javafx.application.Application;

import javafx.geometry.Insets;

import javafx.scene.Scene;

import javafx.scene.control.*;

import javafx.scene.layout.GridPane;

import javafx.stage.Stage;


public class Vente extends Application {





	@Override

	public void start(Stage primaryStage) {

		primaryStage.setTitle("Gestion de pharmacie - Vente");
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10, 10, 10, 10));
		grid.setVgap(5);
		grid.setHgap(5);


// Libellés

		Label labelNomProduit = new Label("Nom du produit :");

		GridPane.setConstraints(labelNomProduit, 0, 0);

		Label labelQuantite = new Label("Quantité :");

		GridPane.setConstraints(labelQuantite, 0, 1);

		Label labelPrixUnitaire = new Label("Prix unitaire :");

		GridPane.setConstraints(labelPrixUnitaire, 0, 2);

		Label labelTotal = new Label("Total :");

		GridPane.setConstraints(labelTotal, 0, 3);


// Champs de saisie

		TextField textFieldNomProduit = new TextField();

		GridPane.setConstraints(textFieldNomProduit, 1, 0);

		TextField textFieldQuantite = new TextField();

		GridPane.setConstraints(textFieldQuantite, 1, 1);

		TextField textFieldPrixUnitaire = new TextField();

		GridPane.setConstraints(textFieldPrixUnitaire, 1, 2);

		TextField textFieldTotal = new TextField();

		GridPane.setConstraints(textFieldTotal, 1, 3);


// Bouton de vente

		Button buttonVendre = new Button("Vendre");

		GridPane.setConstraints(buttonVendre, 1, 4);

		buttonVendre.setOnAction(event -> {

			String nomProduit = textFieldNomProduit.getText();

			int quantite = Integer.parseInt(textFieldQuantite.getText());

			double prixUnitaire = Double.parseDouble(textFieldPrixUnitaire.getText());

			double total = quantite * prixUnitaire;

			textFieldTotal.setText(String.valueOf(total));


// Génération de la facture

			TextArea textAreaFacture = new TextArea();

			textAreaFacture.setEditable(false);

			textAreaFacture.appendText("Pharmacie XYZ\n\n");

			textAreaFacture.appendText("Nom du produit : " + nomProduit + "\n");

			textAreaFacture.appendText("Quantité : " + quantite + "\n");

			textAreaFacture.appendText("Prix unitaire : " + prixUnitaire + "\n");

			textAreaFacture.appendText("Total : " + total + "\n");

			textAreaFacture.appendText("\nMerci de votre achat !");


			GridPane.setConstraints(textAreaFacture, 0, 5, 2, 1);

			grid.getChildren().add(textAreaFacture);

		});


		grid.getChildren().addAll(

				labelNomProduit, labelQuantite, labelPrixUnitaire, labelTotal,

				textFieldNomProduit, textFieldQuantite, textFieldPrixUnitaire, textFieldTotal,

				buttonVendre);


		Scene scene = new Scene(grid, 300, 250);

		primaryStage.setScene(scene);

		primaryStage.show();

	}

}




