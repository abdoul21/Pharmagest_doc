package PharmaGest;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

import java.io.IOException;


public class pagePrincipaleControlleur {

    private Button client_redirec;
    @FXML
    private Button medicament_redirec;
    @FXML
    private Button vente_redirec;
    @FXML
    private Button fourisseur_redirec;
    @FXML
    private Button inventaire_redirec;
    @FXML
    private Button deconexion;

    private Parent root;
    private Stage stage;
    private Scene scene;


    public void cancelButtonAction (ActionEvent event){
        Stage stage = (Stage) deconexion.getScene().getWindow();
        stage.close();
    }

    //bouton pour redirection
    public void medicament_redirect(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("JavaFX/medicaments.fxml"));
        root = loader.load();

        Controllermed Controllermed= loader.getController();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }//bouton pour redirection
    public void client_redirect(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("JavaFX/client.fxml"));
        root = loader.load();

        Controllermed Controllermed= loader.getController();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    //bouton pour redirection
    public void vent_redirect(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("JavaFX/vente.fxml"));
        root = loader.load();

        Controllermed Controllermed= loader.getController();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    //bouton pour redirection
    public void fournisseur_redirect(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("JavaFX/Fournisseurs.fxml"));
        root = loader.load();

        Fournisseurs Fournisseurs= loader.getController();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    //bouton pour redirection
    public void inventaire_redirect(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("JavaFX/stock.fxml"));
        root = loader.load();

        Stock Stock  = loader.getController();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    public void look_redirect(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("JavaFX/affichpage.fxml"));
        root = loader.load();

        Stock Stock  = loader.getController();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    //bouton pour redirection

    }


